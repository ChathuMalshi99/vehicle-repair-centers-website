        <!-- Nav Bar Start -->
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-lg bg-dark navbar-dark">
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="index.php" class="nav-item nav-link active">Home</a>
                            <a href="booked.php" class="nav-item nav-link">booked</a>
                            <a href="contactUs.php" class="nav-item nav-link">Contact Us</a>
                        </div>
                        <div class="ml-auto"> 
                        <div class="col-4">
                            <a class="btn btn-custom" href="php/logout.php"><i class="fa fa-user"></i>LogOut</a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
        <!-- Nav Bar End -->